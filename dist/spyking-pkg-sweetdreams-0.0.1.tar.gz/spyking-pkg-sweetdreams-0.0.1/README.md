Simple package I created to help my lab simulate a spiking neural network.

Emphasis put on being biomimetic and modularity
